<?php

function conectar(){
    $mail="";
    $server="localhost";
    $db="Mails";
    $con=mysql_connect($server, $mail) or die ("error al conectar" .mysql_error());
    mysql_select_db($db, $con);

    return $con;
} 

?>