<?php

include("conexion.php");

$con=conectar();

echo "se guardo tu gmail exitosamente";

?>