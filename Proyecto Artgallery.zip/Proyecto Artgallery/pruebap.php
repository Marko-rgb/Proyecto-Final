<html>

<head>
  <title>Captura de datos del form</title>
</head>

<body>
  <?php
  echo "El nombre ingresado es:";
  echo $_REQUEST['nombre'];
  ?>
</body>

</html>